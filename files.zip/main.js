/**
 * main.js  ← entry point
 * Import and initialise all modules for auth-page.html.
 *
 * Add this to your HTML just before </body>:
 *   <script type="module" src="./main.js"></script>
 *
 * File map:
 *   main.js          ← you are here (boots everything)
 *   overlay.js       ← sliding panel toggle
 *   formHandlers.js  ← Sign In / Sign Up submit logic
 *   validation.js    ← field validation rules
 *   toast.js         ← notification utility
 */

import { initOverlay }               from './overlay.js';
import { initSignInForm, initSignUpForm } from './formHandlers.js';
import { showToast }                 from './toast.js';

// ── Boot once the DOM is ready ──
document.addEventListener('DOMContentLoaded', () => {

  // 1. Wire up the sliding overlay
  initOverlay();

  // 2. Wire up Sign In submission
  initSignInForm({
    onSuccess: ({ email }) => {
      showToast(`Welcome back, ${email}!`);
    },
    onError: (errors) => {
      showToast(errors[0], 'error');
    },
  });

  // 3. Wire up Sign Up submission
  initSignUpForm({
    onSuccess: ({ name }) => {
      showToast(`Account created! Welcome, ${name} 🎉`);
    },
    onError: (errors) => {
      showToast(errors[0], 'error');
    },
  });

});
