/**
 * validation.js
 * Validates Sign In and Sign Up form fields before submission.
 * Returns { valid: boolean, errors: string[] }
 */

/**
 * Validate an email string format.
 * @param {string} email
 * @returns {boolean}
 */
export function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

/**
 * Validate Sign In fields.
 * @param {{ email: string, password: string }} fields
 * @returns {{ valid: boolean, errors: string[] }}
 */
export function validateSignIn({ email, password }) {
  const errors = [];

  if (!email.trim()) {
    errors.push('Email is required.');
  } else if (!isValidEmail(email)) {
    errors.push('Please enter a valid email address.');
  }

  if (!password) {
    errors.push('Password is required.');
  }

  return { valid: errors.length === 0, errors };
}

/**
 * Validate Sign Up fields.
 * @param {{ firstName: string, lastName: string, email: string, password: string }} fields
 * @returns {{ valid: boolean, errors: string[] }}
 */
export function validateSignUp({ firstName, lastName, email, password }) {
  const errors = [];

  if (!firstName.trim()) errors.push('First name is required.');
  if (!lastName.trim())  errors.push('Last name is required.');

  if (!email.trim()) {
    errors.push('Email is required.');
  } else if (!isValidEmail(email)) {
    errors.push('Please enter a valid email address.');
  }

  if (!password) {
    errors.push('Password is required.');
  } else if (password.length < 8) {
    errors.push('Password must be at least 8 characters.');
  }

  return { valid: errors.length === 0, errors };
}
