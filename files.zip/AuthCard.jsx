/**
 * AuthCard.jsx
 * Self-contained sliding-overlay auth card.
 * Drop this into any React (17+) project — no extra dependencies needed.
 *
 * Usage:
 *   import AuthCard from './AuthCard';
 *   <AuthCard onSignIn={(data) => console.log(data)}
 *             onSignUp={(data) => console.log(data)} />
 */

import { useState, useCallback } from "react";

// ─────────────────────────────────────────────
// SVG icons
// ─────────────────────────────────────────────
const GoogleIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
  </svg>
);

const GitHubIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/>
  </svg>
);

// ─────────────────────────────────────────────
// Validation helpers (mirrors validation.js)
// ─────────────────────────────────────────────
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

function validateSignIn({ email, password }) {
  const errors = [];
  if (!email.trim())          errors.push("Email is required.");
  else if (!isValidEmail(email)) errors.push("Please enter a valid email address.");
  if (!password)              errors.push("Password is required.");
  return { valid: errors.length === 0, errors };
}

function validateSignUp({ firstName, lastName, email, password }) {
  const errors = [];
  if (!firstName.trim()) errors.push("First name is required.");
  if (!lastName.trim())  errors.push("Last name is required.");
  if (!email.trim())     errors.push("Email is required.");
  else if (!isValidEmail(email)) errors.push("Please enter a valid email address.");
  if (!password)         errors.push("Password is required.");
  else if (password.length < 8) errors.push("Password must be at least 8 characters.");
  return { valid: errors.length === 0, errors };
}

// ─────────────────────────────────────────────
// Toast (internal state — no external lib)
// ─────────────────────────────────────────────
function Toast({ message, type }) {
  if (!message) return null;
  return (
    <div style={{
      position:     "fixed",
      bottom:       "2rem",
      left:         "50%",
      transform:    "translateX(-50%)",
      background:   "#17171a",
      color:        "#f7f4ef",
      padding:      "0.65rem 1.4rem",
      borderRadius: "40px",
      fontSize:     "0.82rem",
      fontWeight:   "500",
      border:       `1px solid ${type === "error" ? "rgba(224,75,74,0.4)" : "rgba(232,197,71,0.25)"}`,
      fontFamily:   "'Instrument Sans', sans-serif",
      zIndex:       9999,
      whiteSpace:   "nowrap",
      pointerEvents:"none",
      animation:    "fadeUp 0.28s ease forwards",
    }}>
      {message}
    </div>
  );
}

// ─────────────────────────────────────────────
// Shared sub-components
// ─────────────────────────────────────────────
function Field({ label, id, type = "text", placeholder, value, onChange, autoComplete }) {
  return (
    <div style={{ marginBottom: "1rem" }}>
      <label htmlFor={id} style={{
        display:       "block",
        fontSize:      "0.71rem",
        fontWeight:    "600",
        color:         "#9e9b94",
        textTransform: "uppercase",
        letterSpacing: "0.08em",
        marginBottom:  "6px",
      }}>
        {label}
      </label>
      <input
        id={id}
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        autoComplete={autoComplete}
        style={{
          width:        "100%",
          height:       "42px",
          background:   "rgba(247,244,239,0.05)",
          border:       "1px solid rgba(247,244,239,0.08)",
          borderRadius: "9px",
          padding:      "0 14px",
          fontFamily:   "'Instrument Sans', sans-serif",
          fontSize:     "0.87rem",
          color:        "#f7f4ef",
          outline:      "none",
          boxSizing:    "border-box",
        }}
      />
    </div>
  );
}

function SocialRow() {
  return (
    <div style={{ display: "flex", gap: "10px" }}>
      {[
        { label: "Google", Icon: GoogleIcon },
        { label: "GitHub", Icon: GitHubIcon },
      ].map(({ label, Icon }) => (
        <button key={label} style={{
          flex:          "1",
          height:        "38px",
          background:    "rgba(247,244,239,0.05)",
          border:        "1px solid rgba(247,244,239,0.08)",
          borderRadius:  "8px",
          color:         "#9e9b94",
          fontFamily:    "'Instrument Sans', sans-serif",
          fontSize:      "0.78rem",
          fontWeight:    "500",
          cursor:        "pointer",
          display:       "flex",
          alignItems:    "center",
          justifyContent:"center",
          gap:           "7px",
        }}>
          <Icon /> {label}
        </button>
      ))}
    </div>
  );
}

function Divider({ text }) {
  const lineStyle = {
    flex:       "1",
    height:     "1px",
    background: "rgba(247,244,239,0.08)",
  };
  return (
    <div style={{
      display:       "flex",
      alignItems:    "center",
      gap:           "10px",
      fontSize:      "0.71rem",
      color:         "#9e9b94",
      margin:        "1rem 0",
      letterSpacing: "0.04em",
    }}>
      <span style={lineStyle} /> {text} <span style={lineStyle} />
    </div>
  );
}

// ─────────────────────────────────────────────
// Sign In form
// ─────────────────────────────────────────────
function SignInForm({ onError, onSuccess }) {
  const [email,    setEmail]    = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = useCallback(() => {
    const { valid, errors } = validateSignIn({ email, password });
    if (!valid) { onError(errors[0]); return; }
    onSuccess({ email });                    // ← swap for real API call
  }, [email, password, onError, onSuccess]);

  return (
    <div style={{ display: "flex", flexDirection: "column", justifyContent: "center", height: "100%", padding: "3rem 3.2rem" }}>
      <h2 style={{ fontFamily: "'Fraunces', serif", fontSize: "2rem", fontWeight: "600", color: "#f7f4ef", letterSpacing: "-0.03em", lineHeight: "1.1", marginBottom: "0.35rem" }}>
        Welcome back
      </h2>
      <p style={{ fontSize: "0.8rem", color: "#9e9b94", marginBottom: "1.8rem" }}>
        Sign in to your account to continue.
      </p>

      <Field label="Email"    id="siEmail" type="email"    placeholder="you@example.com" value={email}    onChange={e => setEmail(e.target.value)}    autoComplete="email" />
      <Field label="Password" id="siPass"  type="password" placeholder="••••••••"        value={password} onChange={e => setPassword(e.target.value)} autoComplete="current-password" />

      <a href="#" style={{ display: "block", textAlign: "right", fontSize: "0.76rem", color: "#9e9b94", textDecoration: "none", marginTop: "-0.5rem", marginBottom: "1.4rem" }}>
        Forgot password?
      </a>

      <button onClick={handleSubmit} style={{
        width: "100%", height: "44px", background: "#e8c547", color: "#0e0e10",
        border: "none", borderRadius: "9px", fontFamily: "'Instrument Sans', sans-serif",
        fontSize: "0.88rem", fontWeight: "600", cursor: "pointer", marginBottom: "1.2rem",
        boxShadow: "0 4px 20px rgba(232,197,71,0.25)",
      }}>
        Sign In
      </button>

      <Divider text="or continue with" />
      <SocialRow />
    </div>
  );
}

// ─────────────────────────────────────────────
// Sign Up form
// ─────────────────────────────────────────────
function SignUpForm({ onError, onSuccess }) {
  const [firstName, setFirstName] = useState("");
  const [lastName,  setLastName]  = useState("");
  const [email,     setEmail]     = useState("");
  const [password,  setPassword]  = useState("");

  const handleSubmit = useCallback(() => {
    const { valid, errors } = validateSignUp({ firstName, lastName, email, password });
    if (!valid) { onError(errors[0]); return; }
    onSuccess({ name: `${firstName} ${lastName}`, email }); // ← swap for real API call
  }, [firstName, lastName, email, password, onError, onSuccess]);

  return (
    <div style={{ display: "flex", flexDirection: "column", justifyContent: "center", height: "100%", padding: "3rem 3.2rem" }}>
      <h2 style={{ fontFamily: "'Fraunces', serif", fontSize: "2rem", fontWeight: "600", color: "#f7f4ef", letterSpacing: "-0.03em", lineHeight: "1.1", marginBottom: "0.35rem" }}>
        Create account
      </h2>
      <p style={{ fontSize: "0.8rem", color: "#9e9b94", marginBottom: "1.8rem" }}>
        Join thousands of teams already building.
      </p>

      <div style={{ display: "flex", gap: "10px" }}>
        <Field label="First name" id="suFirst" placeholder="Jane"  value={firstName} onChange={e => setFirstName(e.target.value)} />
        <Field label="Last name"  id="suLast"  placeholder="Smith" value={lastName}  onChange={e => setLastName(e.target.value)} />
      </div>

      <Field label="Email"    id="suEmail" type="email"    placeholder="jane@company.com" value={email}    onChange={e => setEmail(e.target.value)}    autoComplete="email" />
      <Field label="Password" id="suPass"  type="password" placeholder="Min. 8 characters" value={password} onChange={e => setPassword(e.target.value)} autoComplete="new-password" />

      <button onClick={handleSubmit} style={{
        width: "100%", height: "44px", background: "#e8c547", color: "#0e0e10",
        border: "none", borderRadius: "9px", fontFamily: "'Instrument Sans', sans-serif",
        fontSize: "0.88rem", fontWeight: "600", cursor: "pointer",
        marginTop: "0.4rem", marginBottom: "1.2rem",
        boxShadow: "0 4px 20px rgba(232,197,71,0.25)",
      }}>
        Create Account
      </button>

      <Divider text="or sign up with" />
      <SocialRow />
    </div>
  );
}

// ─────────────────────────────────────────────
// Overlay panel
// ─────────────────────────────────────────────
function OverlayPanel({ isRightActive, onGoToSignUp, onGoToSignIn }) {
  const msgBase = {
    position:       "absolute",
    top:            "50%",
    left:           "50%",
    width:          "100%",
    padding:        "0 2.8rem",
    display:        "flex",
    flexDirection:  "column",
    alignItems:     "center",
    transition:     "opacity 0.3s ease 0.15s, transform 0.35s cubic-bezier(0.77,0,0.175,1) 0.15s",
    boxSizing:      "border-box",
  };

  const signInMsgStyle = {
    ...msgBase,
    opacity:   isRightActive ? 0 : 1,
    transform: isRightActive ? "translate(-50%, calc(-50% - 12px))" : "translate(-50%, -50%)",
    pointerEvents: isRightActive ? "none" : "all",
  };

  const signUpMsgStyle = {
    ...msgBase,
    opacity:   isRightActive ? 1 : 0,
    transform: isRightActive ? "translate(-50%, -50%)" : "translate(-50%, calc(-50% + 12px))",
    pointerEvents: isRightActive ? "all" : "none",
  };

  const Logo = () => (
    <div style={{ fontFamily: "'Fraunces', serif", fontSize: "1.3rem", fontWeight: "600", color: "#e8c547", letterSpacing: "-0.02em", marginBottom: "2rem", display: "flex", alignItems: "center", gap: "7px" }}>
      <span style={{ width: "10px", height: "10px", borderRadius: "50%", border: "2px solid #e8c547", display: "inline-block" }} />
      Prism
    </div>
  );

  const headingStyle = { fontFamily: "'Fraunces', serif", fontSize: "1.65rem", fontWeight: "600", color: "#f7f4ef", letterSpacing: "-0.03em", lineHeight: "1.15", marginBottom: "0.75rem", textAlign: "center" };
  const paraStyle    = { fontSize: "0.82rem", color: "rgba(247,244,239,0.5)", lineHeight: "1.65", maxWidth: "220px", marginBottom: "2rem", fontWeight: "400", textAlign: "center" };

  const ghostBtn = {
    height: "40px", padding: "0 2rem", background: "transparent",
    border: "1px solid rgba(232,197,71,0.45)", borderRadius: "40px", color: "#e8c547",
    fontFamily: "'Instrument Sans', sans-serif", fontSize: "0.82rem", fontWeight: "600",
    cursor: "pointer", letterSpacing: "0.04em",
  };

  const Dots = ({ activeIndex }) => (
    <div style={{ display: "flex", gap: "5px", marginTop: "1.5rem" }}>
      {[0, 1].map(i => (
        <span key={i} style={{
          width: "5px", height: "5px", borderRadius: "50%",
          background: i === activeIndex ? "#e8c547" : "rgba(232,197,71,0.25)",
          transition: "background 0.3s",
        }} />
      ))}
    </div>
  );

  return (
    <div style={{
      position:   "absolute",
      top: 0, bottom: 0,
      width:      "50%",
      left:       isRightActive ? "50%" : "0",
      background: "linear-gradient(135deg, #1a1207 0%, #2a1f05 40%, #1c1a07 100%)",
      transition: "left 0.65s cubic-bezier(0.77,0,0.175,1)",
      zIndex:     10,
      overflow:   "hidden",
    }}>
      {/* decorative ring */}
      <div style={{
        position: "absolute", width: "280px", height: "280px",
        border: "1px solid rgba(232,197,71,0.1)", borderRadius: "50%",
        top: "50%", left: "50%", transform: "translate(-50%,-50%)",
        pointerEvents: "none",
      }} />

      {/* Sign-in-state message */}
      <div style={signInMsgStyle}>
        <Logo />
        <h3 style={headingStyle}>New here?<br /><em style={{ fontStyle: "italic", color: "#e8c547" }}>Join us.</em></h3>
        <p style={paraStyle}>Create an account and start your journey with us today.</p>
        <button style={ghostBtn} onClick={onGoToSignUp}>Create Account</button>
        <Dots activeIndex={0} />
      </div>

      {/* Sign-up-state message */}
      <div style={signUpMsgStyle}>
        <Logo />
        <h3 style={headingStyle}>Already have<br />an <em style={{ fontStyle: "italic", color: "#e8c547" }}>account?</em></h3>
        <p style={paraStyle}>Sign in and pick up right where you left off.</p>
        <button style={ghostBtn} onClick={onGoToSignIn}>Sign In</button>
        <Dots activeIndex={1} />
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
// Root component — AuthCard
// ─────────────────────────────────────────────

/**
 * @param {{ onSignIn?: (data: object) => void, onSignUp?: (data: object) => void }} props
 */
export default function AuthCard({ onSignIn, onSignUp }) {
  const [rightActive, setRightActive] = useState(false);
  const [toast, setToast]             = useState({ message: "", type: "info" });

  const showToast = useCallback((message, type = "info") => {
    setToast({ message, type });
    setTimeout(() => setToast({ message: "", type: "info" }), 3000);
  }, []);

  const handleSignInSuccess = useCallback((data) => {
    showToast(`Welcome back, ${data.email}!`);
    onSignIn?.(data);
  }, [showToast, onSignIn]);

  const handleSignUpSuccess = useCallback((data) => {
    showToast(`Account created! Welcome, ${data.name} 🎉`);
    onSignUp?.(data);
  }, [showToast, onSignUp]);

  const handleError = useCallback((msg) => {
    showToast(msg, "error");
  }, [showToast]);

  return (
    <>
      {/* Google Fonts */}
      <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,600;1,9..144,300&family=Instrument+Sans:wght@400;500;600&display=swap" rel="stylesheet" />

      {/* Keyframes for toast */}
      <style>{`@keyframes fadeUp { from { opacity:0; transform:translateX(-50%) translateY(12px); } to { opacity:1; transform:translateX(-50%) translateY(0); } }`}</style>

      {/* Page wrapper */}
      <div style={{
        minHeight:      "100vh",
        display:        "flex",
        alignItems:     "center",
        justifyContent: "center",
        background:     "#0e0e10",
        fontFamily:     "'Instrument Sans', sans-serif",
      }}>
        {/* Card */}
        <div style={{
          position:     "relative",
          width:        "820px",
          height:       "520px",
          background:   "#17171a",
          borderRadius: "20px",
          border:       "1px solid rgba(247,244,239,0.08)",
          overflow:     "hidden",
          boxShadow:    "0 40px 100px rgba(0,0,0,0.6)",
        }}>
          {/* Forms wrap */}
          <div style={{ position: "absolute", inset: 0, display: "flex" }}>
            {/* Sign In — left 50% */}
            <div style={{
              width:      "50%",
              flexShrink: 0,
              order:      1,
              opacity:    rightActive ? 0 : 1,
              pointerEvents: rightActive ? "none" : "all",
              transition: "opacity 0.65s cubic-bezier(0.77,0,0.175,1)",
            }}>
              <SignInForm onSuccess={handleSignInSuccess} onError={handleError} />
            </div>

            {/* Sign Up — right 50% */}
            <div style={{
              width:      "50%",
              flexShrink: 0,
              order:      2,
              opacity:    rightActive ? 1 : 0,
              pointerEvents: rightActive ? "all" : "none",
              transition: "opacity 0.65s cubic-bezier(0.77,0,0.175,1)",
            }}>
              <SignUpForm onSuccess={handleSignUpSuccess} onError={handleError} />
            </div>
          </div>

          {/* Sliding overlay */}
          <OverlayPanel
            isRightActive={rightActive}
            onGoToSignUp={() => setRightActive(true)}
            onGoToSignIn={() => setRightActive(false)}
          />
        </div>
      </div>

      {/* Toast */}
      <Toast message={toast.message} type={toast.type} />
    </>
  );
}
