/**
 * toast.js
 * Lightweight toast notification — shows a message at the bottom of the screen.
 *
 * Usage:
 *   import { showToast } from './toast.js';
 *   showToast('Signed in successfully!');
 *   showToast('Invalid email.', 'error');
 */

let toastEl = null;
let hideTimer = null;

/**
 * Creates the toast DOM element once and reuses it.
 * @returns {HTMLElement}
 */
function getToast() {
  if (toastEl) return toastEl;

  toastEl = document.createElement('div');
  toastEl.id = 'toast';

  Object.assign(toastEl.style, {
    position:        'fixed',
    bottom:          '2rem',
    left:            '50%',
    transform:       'translateX(-50%) translateY(16px)',
    background:      '#17171a',
    color:           '#f7f4ef',
    padding:         '0.65rem 1.4rem',
    borderRadius:    '40px',
    fontSize:        '0.82rem',
    fontWeight:      '500',
    opacity:         '0',
    pointerEvents:   'none',
    transition:      'opacity 0.28s ease, transform 0.28s ease',
    zIndex:          '9999',
    whiteSpace:      'nowrap',
    border:          '1px solid rgba(247,244,239,0.1)',
    fontFamily:      "'Instrument Sans', sans-serif",
  });

  document.body.appendChild(toastEl);
  return toastEl;
}

/**
 * Display a toast message.
 * @param {string} message   - Text to display
 * @param {'info'|'error'} [type='info'] - Affects accent colour
 * @param {number} [duration=2800] - How long (ms) before auto-hide
 */
export function showToast(message, type = 'info', duration = 2800) {
  const toast = getToast();

  // Colour by type
  toast.style.borderColor = type === 'error'
    ? 'rgba(224,75,74,0.4)'
    : 'rgba(232,197,71,0.25)';

  toast.textContent = message;

  // Show
  toast.style.opacity   = '1';
  toast.style.transform = 'translateX(-50%) translateY(0)';

  // Clear any previous auto-hide
  if (hideTimer) clearTimeout(hideTimer);

  hideTimer = setTimeout(() => {
    toast.style.opacity   = '0';
    toast.style.transform = 'translateX(-50%) translateY(16px)';
  }, duration);
}
