/**
 * formHandlers.js
 * Wires up submit behaviour for Sign In and Sign Up forms.
 * Reads field values → runs validation → calls onSuccess / onError callbacks.
 *
 * Usage:
 *   import { initSignInForm, initSignUpForm } from './formHandlers.js';
 *   initSignInForm({ onSuccess, onError });
 *   initSignUpForm({ onSuccess, onError });
 */

import { validateSignIn, validateSignUp } from './validation.js';

/**
 * Attach submit handler to the Sign In form button.
 * @param {{ onSuccess: (data: object) => void, onError: (errors: string[]) => void }} callbacks
 */
export function initSignInForm({ onSuccess, onError }) {
  const btn      = document.getElementById('btnSignIn');
  const emailEl  = document.getElementById('signInEmail');
  const passEl   = document.getElementById('signInPassword');

  if (!btn || !emailEl || !passEl) {
    console.warn('[formHandlers.js] Sign In elements not found.');
    return;
  }

  btn.addEventListener('click', () => {
    const fields = {
      email:    emailEl.value,
      password: passEl.value,
    };

    const { valid, errors } = validateSignIn(fields);

    if (!valid) {
      onError(errors);
      return;
    }

    // ── Replace this block with your real API call ──
    onSuccess({ email: fields.email });
  });
}

/**
 * Attach submit handler to the Sign Up form button.
 * @param {{ onSuccess: (data: object) => void, onError: (errors: string[]) => void }} callbacks
 */
export function initSignUpForm({ onSuccess, onError }) {
  const btn         = document.getElementById('btnSignUp');
  const firstEl     = document.getElementById('signUpFirstName');
  const lastEl      = document.getElementById('signUpLastName');
  const emailEl     = document.getElementById('signUpEmail');
  const passEl      = document.getElementById('signUpPassword');

  if (!btn || !firstEl || !lastEl || !emailEl || !passEl) {
    console.warn('[formHandlers.js] Sign Up elements not found.');
    return;
  }

  btn.addEventListener('click', () => {
    const fields = {
      firstName: firstEl.value,
      lastName:  lastEl.value,
      email:     emailEl.value,
      password:  passEl.value,
    };

    const { valid, errors } = validateSignUp(fields);

    if (!valid) {
      onError(errors);
      return;
    }

    // ── Replace this block with your real API call ──
    onSuccess({ email: fields.email, name: `${fields.firstName} ${fields.lastName}` });
  });
}
