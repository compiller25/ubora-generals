/**
 * overlay.js
 * Controls the sliding overlay panel between Sign In and Sign Up.
 *
 * How it works:
 * - Adds / removes the "right-active" CSS class on .card
 * - CSS transitions on .overlay handle all animation (no JS animation)
 * - CSS opacity transitions on .form-panel handle the form fade
 */

export function initOverlay() {
  const card        = document.getElementById('card');
  const btnToSignup = document.getElementById('btnToSignup');
  const btnToSignin = document.getElementById('btnToSignin');

  if (!card || !btnToSignup || !btnToSignin) {
    console.warn('[overlay.js] Required elements not found in DOM.');
    return;
  }

  /** Slide overlay to the right → reveal Sign Up form */
  btnToSignup.addEventListener('click', () => {
    card.classList.add('right-active');
  });

  /** Slide overlay back to the left → reveal Sign In form */
  btnToSignin.addEventListener('click', () => {
    card.classList.remove('right-active');
  });
}
